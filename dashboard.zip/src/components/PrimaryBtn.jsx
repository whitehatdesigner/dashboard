import React from 'react'

const PrimaryBtn = (props) => {
  return (
   <button className='primary-btn'>
    {props.name}
   </button>
  )
}

export default PrimaryBtn