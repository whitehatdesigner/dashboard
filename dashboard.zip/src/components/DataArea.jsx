import React from 'react'

const DataArea = () => {
  return (
    <div>DataArea</div>
  )
}

export default DataArea