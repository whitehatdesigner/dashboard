import React from 'react'

const Discounts = () => {
  return (
    <div>
        
    </div>
  )
}

export default Discounts