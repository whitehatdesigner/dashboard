import React from 'react'

const AdminLogin = () => {
  return (
    <div>
      {/* <img src={URL.createObjectURL()} alt="" /> */}
    </div>
  )
}

export default AdminLogin