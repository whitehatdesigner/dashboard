import { Images } from "../assets/images/images";

export const adminProfile = [
    {
        _id: "2025",
        userName: "Ankit_shukla01",
        firstname: "Ankit",
        lastname: "Shukla",
        dob: "05-Mar-2003",
        emailAddress: "test@gmail.com",
        phoneNumber: "9899-506-105",
        password: "1234",
        useRole: "Admin",
        Country: "India",
        City: "Delhi",
        zipCode: "110094",
        profileImg: [Images.profileImg]
    },
    {
        _id: "2026",
        userName: "riya_singh22",
        firstname: "Riya",
        lastname: "Singh",
        dob: "12-Jul-2000",
        emailAddress: "riya.singh@example.com",
        phoneNumber: "9876-123-456",
        password: "abcd1234",
        useRole: "User",
        Country: "India",
        City: "Mumbai",
        zipCode: "400001",
        profileImg: [Images.riyaProfileImg]
    },

]