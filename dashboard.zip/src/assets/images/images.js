import logo from './logo.png'
import profileIcon from './profile-icon.jpg'
import dummyImg from './dummy-img.jpg'
import p1 from './other/p-1.png'
import uploadImg from './other/upload-img.jpg'
import menImage from './categories/men.jpg'
import womenImage from './categories/women.jpg'
import kidsImage from './categories/kids.jpg'
import topwearImage from './categories/topwear.jpg'
import winterwearImage from './categories/winterwear.jpg'
import bottomwearImage from './categories/bottomwear.jpg'
import profileImg from './user/ankit-img.jpg'
import riyaProfileImg from './user/riya.jpg'


export const Images = {
    logo, profileIcon, dummyImg, p1, uploadImg, menImage, womenImage, kidsImage, topwearImage, winterwearImage, bottomwearImage, profileImg, riyaProfileImg
}